export class Transaction
{
  transId:number;
  accountId:number;
  amount:number;
  type:String; 
  dateOfTrans:Date;
  chequeId:number;
}
