import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PassbookComponent } from './passbook/passbook.component';
import { UpdateComponent } from './update/update.component';
import { SummaryComponent } from './summary/summary.component';
import {FormsModule} from '@angular/forms';
import {PassbookService} from './Services/passbook.service';
import { HttpClientModule } from '@angular/common/http';
import { ViewComponent } from './view/view.component';
import {PassService} from './pass.service';

@NgModule({
  declarations: [
    AppComponent,
    PassbookComponent,
    UpdateComponent,
    SummaryComponent,
    ViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [PassbookService,PassService],
  bootstrap: [AppComponent]
})
export class AppModule { }
