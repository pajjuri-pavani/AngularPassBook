export class Transaction
{
  transId:number;
  accId:number;
  amount:number;
  type:String; 
  chequeId:number;
  dateOfTrans:Date;
  public constructor(transId:number,accId:number,amount:number,type:String, chequeId:number,dateOfTrans:Date):void
  {
     this.transId = transId;
     this.accId = accId;
     this.amount = amount;
     this.type = type;
     this.chequeId = chequeId;
     this.dateOfTrans = dateOfTrans;
  }
}
