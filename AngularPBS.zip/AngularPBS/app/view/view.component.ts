import { Component, OnInit,ViewChild,Input} from '@angular/core';
import {Transaction} from 'D:/AngularProjects/PecuniaBankSystem/src/app/Dto/transaction';
import {UpdateComponent} from 'D:/AngularProjects/PecuniaBankSystem/src/app/update/update.component';
import {PassService} from 'D:/AngularProjects/PecuniaBankSystem/src/app/pass.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit 
{
  trans:Transaction[]= [];
  constructor(private passService:PassService) { }
  ngOnInit(): void 
  {
  	this.passService.transaction$.subscribe(data => {
							for(var t of data)
							  this.trans.push(t);
							});
  }
}
